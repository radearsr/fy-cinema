import "./nav-app.js";
import "./hero-section.js";
import "./search-bar.js";
import "./result-film.js";
import "./detail-list.js";
import "./trailer-list.js";
